package com.cg.Servlets.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class dao 
{
	Connection conn=null;
	PreparedStatement ps=null;
	public Connection getConnection()
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@localhost:1521:XE";
			String user="system";
			String pass="Capgemini123";
			conn =DriverManager.getConnection(url,user,pass);
			return conn;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return conn;
}
	
	public boolean validAdminLogin(String adminusername,String adminpassword)
    {
    	try 
    	{
    		conn =getConnection();
        	String sql ="select * from admin_login where username=? and password=?";
        	ps=conn.prepareStatement(sql);
        	ps.setString(1, adminusername);
        	ps.setString(2, adminpassword);
        	ResultSet rs=ps.executeQuery();
    		return rs.next();
    	}
    	catch  (Exception e) 
    	{
    		
    		e.printStackTrace();
    	}
    	return false;
    }
	
	public boolean addCustomerDetails(String cfirstname,String clastname,String cmobilenumber,String clocation)
    {
    	try 
    	{
    		conn =getConnection();
        	String sql ="insert into customer_details values(?,?,?,?)";
        	ps=conn.prepareStatement(sql);
        	ps.setString(1,cfirstname);
        	ps.setString(2, clastname);
        	ps.setString(3,cmobilenumber);
        	ps.setString(4, clocation);
        	
        	ResultSet rs=ps.executeQuery();
    		return rs.next();
    	}
    	catch  (Exception e)
        {
    		
    		e.printStackTrace();
    	}
    	return false;
    }

}
