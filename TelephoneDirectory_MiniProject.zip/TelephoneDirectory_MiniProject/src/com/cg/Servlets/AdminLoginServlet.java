package com.cg.Servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.Servlets.Dao.dao;
import com.cg.Servlets.Dao.dao;

/**
 * Servlet implementation class AdminLoginServlet
 */
@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
			response.setContentType("text/html");//content type of response to client by server for given request(by client)
			PrintWriter out=response.getWriter();//writes content on webpage
			
			String adminusername=request.getParameter("ausername");
			String adminpassword=request.getParameter("apassword");
			
			dao dao =new dao();
			boolean result=dao.validAdminLogin(adminusername,adminpassword);
			System.out.println(result);
			if (result)
			{ 
				RequestDispatcher rd=request.getRequestDispatcher("adminhome.jsp");
			    rd.forward(request, response);
			}
			else
			{
	           RequestDispatcher rd=request.getRequestDispatcher("adminlogin.jsp?emsg=username/password is not valid");//URLRewriting session tracking
			   rd.include(request, response);
			}
			}

}
